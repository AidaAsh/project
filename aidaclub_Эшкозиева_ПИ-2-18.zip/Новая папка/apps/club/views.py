from __future__ import division
from django.db.models import Q
from django.views.generic import ListView,DetailView
from django.shortcuts import redirect, render
from .models import *
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.models import User, Group


class StaffListView(LoginRequiredMixin,ListView):
    model = UserClub
    template_name = 'list.html'
    context_object_name = 'employee'
    paginate_by = 20


def AidaView(request):
    return render(request,"index.html")


@login_required
def ClubAuthorizathion(request):
    return render(request,"account-admin.html")


def Clubaccountuser(request, id):
        user = User.objects.get(id=id)
        personal = UserClub.objects.get(email=user)
        position = PositionClub.objects.get(userclub_id=personal.id)

        return render(request, "account-admin.html",
                      context={"user": user, "personal": personal, "positions":position})


from datetime import date

@login_required
def booking(request, id):
    if request.method == "GET":
        user = User.objects.get(id=id)
        personal = UserClub.objects.get(email=user)
        return render(request,"booking.html", context={"user": user, "personal": personal})
    if request.method == "POST":
        sss = int(request.POST.get('user-id'))
        obj = UserClub.objects.get(id=sss)
        date_of_booking = request.POST.get('dateofbooking')
        timestart = request.POST.get('time')
        if timestart=="13:00":
            timeend = "14:00"
        elif timestart=="14:00":
            timeend = "15:00"
        elif timestart=="15:00":
            timeend = "16:00"
        elif timestart=="16:00":
            timeend = "17:00"
        elif timestart == "17:00":
            timeend = "18:00"
        elif timestart=="18:00":
            timeend = "19:00"
        elif timestart=="19:00":
            timeend = "20:00"
        elif timestart=="20:00":
            timeend = "21:00"
        number = obj.number_phone
        date_of_today = date.today()
        status="Ожидание"
        Bookings.objects.create(userclub=obj, date_of_booking=date_of_booking,timestart=timestart, timeend=timeend,email=number,status=status, date_of_today=date_of_today  )
        return render(request, "index.html")
    return render(request, "booking.html")


def approveteam(request):
    if request.method == "GET":
        obj = TeamsGrup.objects.all()
        objs = TeamUs.objects.all()
        return render(request, "approve-team.html", {"obj":obj,"objs":objs })
    return render(request,"approve-team.html")

@login_required
def cancelbooking(request, id):
    if request.method == "GET":
        user = User.objects.get(id=id)
        personal = UserClub.objects.get(user=id)
        bookings = personal.bookings.latest("id")

        return render(request, "cancel-booking.html", context={"user": user, "personal": personal,"bookings":bookings})
    if request.method == "POST":
        sss = int(request.POST.get('user-id'))
        obj = UserClub.objects.get(id=sss)
        bookings = Bookings.objects.get(id=obj.id)
        bookings.delete()

        return render(request, "index.html")
    return render(request,"cancel-booking.html")


def commandteam(request):
    if request.method == "GET":
        obj = TeamsGrup.objects.all()
        objs = TeamUs.objects.all()
        return render(request, "command-team.html", {"obj": obj, "objs": objs})
    return render(request,"command-team.html")

@login_required
def createadmin(request):
    if request.method == "GET":
        obj = UserClub.objects.all()
        return render(request,"create-admin.html", {'obj':obj})
    if request.method == "POST":
        fname = request.POST.get('admins')
        obj = UserClub.objects.all()
        for i in obj:
            if i.full_name == fname:
                objs = UserClub.objects.get(id=i.id)
        pcog = PositionClub.objects.get(userclub_id=objs.id)
        pcog.position = "Администратор"
        pcog.save()
        return render(request, "create-admin.html")


def getchild(request):
    if request.method == "GET":
        obj = TeamLessons.objects.all()
        return render(request, "get-child.html", {"obj":obj})
    return render(request,"get-child.html")


def gettraningteam(request):
    if request.method == "GET":
        obj = TeamLessons.objects.all()
        return render(request, "get-child.html", {"obj":obj})
    return render(request,"get-traning-team.html")


def lesschild(request):
    if request.method == "GET":
        obj = TeamsGrup.objects.all()
        return render(request,"less-child.html", {'obj':obj})
    if request.method == "POST":
        fname = request.POST.get('teams')
        obj = TeamsGrup.objects.all()
        for i in obj:
            if i.group == fname:
                objs = TeamsGrup.objects.get(id=i.id)
        groups = TeamsGrup.objects.get(id=objs.id)
        first_name = request.POST.get('first_name')
        surname =request.POST.get('surname')
        last_name = request.POST.get('last_name')
        number_phone = request.POST.get('number_phone')
        email =request.POST.get('email')
        data_of_birth = request.POST.get('data_of_birth')
        gender = request.POST.get('gender')
        TeamUs.objects.create(groups=groups,  first_name=first_name, surname=surname,last_name=last_name, number_phone=number_phone,email=email,data_of_birth=data_of_birth,gender=gender)
        return render(request, "reports-less.html")
    return render(request,"less-child.html")


def newteam(request):
    if request.method == "POST":
        group = request.POST.get('group')
        first_name =request.POST.get('first_name')
        surname = request.POST.get('surname')
        last_name = request.POST.get('last_name')
        number_phone = request.POST.get('number_phone')
        email = request.POST.get('email')
        data_of_birth = request.POST.get('data_of_birth')
        gender =request.POST.get('gender')
        TeamsGrup.objects.create(group=group,first_name=first_name,surname=surname,last_name=last_name,number_phone=number_phone,email=email,data_of_birth=data_of_birth,gender=gender)
        obj = TeamsGrup.objects.latest('id')
        first_name = request.POST.get('first_name0')
        surname = request.POST.get('surname0')
        last_name = request.POST.get('last_name0')
        number_phone = request.POST.get('number_phone0')
        email = request.POST.get('email0')
        data_of_birth = request.POST.get('data_of_birth0')
        gender = request.POST.get('gender0')
        TeamUs.objects.create(groups=obj, first_name=first_name, surname=surname,
                                 last_name=last_name, number_phone=number_phone, email=email,
                                 data_of_birth=data_of_birth, gender=gender)
        if first_name != "":
            o = 0
            for o in range(1, 15):
                first_name = request.POST.get('first_name' + str(o))
                testing = None
                if first_name != testing:
                    first_name = request.POST.get('first_name' + str(o))
                    surname = request.POST.get('surname' + str(o))
                    last_name = request.POST.get('last_name' + str(o))
                    number_phone = request.POST.get('number_phone' + str(o))
                    email = request.POST.get('email' + str(o))
                    data_of_birth = request.POST.get('data_of_birth' + str(o))
                    gender = request.POST.get('gender' + str(o))
                    TeamUs.objects.create(groups=obj, first_name=first_name, surname=surname,
                                             last_name=last_name, number_phone=number_phone, email=email,
                                             data_of_birth=data_of_birth, gender=gender)
        return render(request, "index.html")
    return render(request,"new-team.html")


def orgturners(request):
    if request.method == "GET":
        return render(request, "org-turners.html")
    if request.method == "POST":
        team_one = request.POST.get('team-one')
        team_two = request.POST.get('team-two')
        date_of_booking = request.POST.get('dateofbooking')
        timestart = request.POST.get('time')
        timeend = request.POST.get('time-end')
        date_of_today = date.today()
        Tournament.objects.create(team_one=team_one, date_of_booking=date_of_booking, timestart=timestart, date_of_today=date_of_today, timeend=timeend,
                                team_two=team_two)
        return render(request, "index.html")
    return render(request,"org-turners.html")


def reportsbooking(request):
    if request.method == "GET":
        status = "Актив"
        status1 = "Ожидание"
        obj = Bookings.objects.filter(Q(status=status))
        obj1 = Bookings.objects.filter(Q(status=status1))
        return render(request, "reports-booking.html", {"obj":obj, "obj1":obj1})
    return render(request,"reports-booking.html")


def reporttableturners(request):
    if request.method == "GET":
        obj = Tournament.objects.all()
        return render(request, "report-table-turners.html", {"obj":obj})
    return render(request,"report-table-turners.html")


def traningteam(request):
    return render(request,"traning-team.html")


def replesschild(request):
    if request.method == "GET":
        obj = TeamsGrup.objects.all()

        return render(request,"repless-child.html", {'obj':obj})
    if request.method == "POST":

        sss = request.POST.get('names')
        obj = TeamsGrup.objects.all()
        for i in obj:
            if i.group == sss:
                objs = TeamsGrup.objects.get(id=i.id)


        weeks = request.POST.get('weeks')
        time =request.POST.get('time')
        timeend =request.POST.get('time-end')
        TimeGraf.objects.create(teamlessons_id=objs.id,weeks=weeks , time=time,timeend=timeend )
        return render(request, "index.html")
    return render(request,"repless-child.html")


def reportsless(request):
    if request.method == "GET":
        obj = TimeGraf.objects.all()
        return render(request, "reports-less.html", {'obj': obj})
    return render(request,"reports-less.html")


def editbookings(request):
    if request.method == "GET":
        status = "Актив"
        status1 = "Ожидание"
        obj = Bookings.objects.filter(Q(status=status))
        obj1 = Bookings.objects.filter(Q(status=status1))
        return render(request, "editbookings.html", {"obj":obj, "obj1":obj1})
    return render(request,"editbookings.html")


def addrovebooking(request, id=None):
    if request.method == "GET":
        obj = Bookings.objects.get(id=id)
        return render(request, "addrovebooking.html", {"obj":obj})
    if request.method == "POST":
        objid = request.POST.get('user-id')
        obj = Bookings.objects.get(id=objid)
        sets = request.POST.get('sets')
        if sets == "Подвердить":
            saveb = obj
            saveb.status = "Актив"
            saveb.save()
        elif sets == "Отказать":
            saveb = obj
            saveb.status = "Отказ"
            saveb.save()
        status = "Актив"
        status1 = "Ожидание"
        obj = Bookings.objects.filter(Q(status=status))
        obj1 = Bookings.objects.filter(Q(status=status1))
        return render(request, "editbookings.html", {"obj":obj, "obj1":obj1})
    return render(request,"addrovebooking.html")


def mybookings(request, id=None):

    if request.method == "GET":
        users = User.objects.get(id=id)
        objs = UserClub.objects.get(email=users)
        objo = Bookings.objects.filter(Q(userclub=objs))
        return render(request, "mybookings.html", {"obj": objo})


def cancelbooking(request, id=None):
    if request.method == "GET":
        obj = Bookings.objects.get(id=id)
        return render(request, "cancelbooking.html", {"obj":obj})

    if request.method == "POST":
        objid = request.POST.get('user-id')
        obj = Bookings.objects.get(id=objid)
        saveb = obj
        saveb.delete()
        return render(request, "index.html")
    return render(request,"cancelbooking.html")