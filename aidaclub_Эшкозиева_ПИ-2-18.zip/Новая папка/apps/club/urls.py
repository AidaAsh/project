from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from .views import *


urlpatterns = [
    path("",AidaView,name='home'),
    path("home/",AidaView,name='homes'),
    path("authorizathion/",ClubAuthorizathion,name='authorizathion'),

    path('accountuser/<int:id>',Clubaccountuser, name='accountuser'),

    path('approve-team/', approveteam, name='approve-team'),
    path('booking/<int:id>', booking, name='booking'),
    path('cancel-booking/<int:id>', cancelbooking, name='cancel-booking'),
    path('command-team/', commandteam, name='command-team'),
    path('create-admin/', createadmin, name='create-admin'),
    path('get-child/', getchild, name='get-child'),
    path('get-traning-team/', gettraningteam, name='get-traning-team'),
    path('less-child/', lesschild, name='less-child'),
    path('new-team/', newteam, name='new-team'),
    path('org-turners/', orgturners, name='org-turners'),
    path('report-booking/', reportsbooking, name='report-booking'),
    path('report-table-turners/', reporttableturners, name='report-table-turners'),
    path('traning-team/', traningteam, name='traning-team'),
    path('replesschild/', replesschild, name='replesschild'),
    path('reportsless/', reportsless, name='reportsless'),
    path('editbookings/', editbookings, name='editbookings'),
    path('cancelbooking/<int:id>', cancelbooking, name='cancelbooking'),
    path('addrovebooking/<int:id>', addrovebooking, name='addrovebooking'),
    path('mybookings/<int:id>', mybookings, name='mybookings'),



]


if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

#urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
