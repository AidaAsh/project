from django.utils.crypto import get_random_string



def triple_latter(obj: str) -> str:
    return "".join([i[0] for i in obj.title().split()])




