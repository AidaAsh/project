from django.contrib import admin
from .models import *


class UserClubAdmin(admin.ModelAdmin):
    list_display = ['full_name', 'number_phone', 'email']
    search_fields = ['email']


class PositionClubAdmin(admin.ModelAdmin):
    list_display = ('get_fullname', 'position')
    actions = ['make_trainer']
    list_filter = ['position']

    def get_fullname(self, obj):
        return obj.userclub.full_name
    get_fullname.short_description = 'Пользователь'
    get_fullname.admin_order_field = 'userclub__full_name'


class BookingsAdmin(admin.ModelAdmin):
    list_display = ('get_fullname', 'date_of_booking','date_of_today', 'timestart','email','status')
    date_hierarchy = 'date_of_booking'
    list_filter = ('status', 'date_of_booking')
    ordering = ['date_of_booking', 'timestart']
    def get_fullname(self, obj):
        return obj.userclub.full_name
    get_fullname.short_description = 'Пользователь'
    get_fullname.admin_order_field = 'userclub__full_name'


class TournamentAdmin(admin.ModelAdmin):
    list_display = ('team_one', 'team_two', 'date_of_booking', 'timestart')
    date_hierarchy = 'date_of_booking'
    list_filter = ('team_one', 'date_of_booking')


class TeamsGrupAdmin(admin.ModelAdmin):
    list_filter = ['surname']
    fieldsets = (
        (None, {
            'fields': ['group']
        }),
        ('Данные тренера', {
            'fields': (('first_name', 'surname', 'last_name'),('number_phone','email'),'data_of_birth','gender')
        }))


class TimeGrafAdmin(admin.ModelAdmin):
    list_filter = ['weeks','teamlessons']

class TeamUsAdmin(admin.ModelAdmin):
    list_display = ('groups', 'first_name', 'surname', 'number_phone')
    date_hierarchy = 'data_of_birth'
    list_filter = ['groups']

class TeamUsAdmin(admin.ModelAdmin):
    list_filter = ['groups']

admin.site.register(UserClub, UserClubAdmin)
admin.site.register(PositionClub, PositionClubAdmin)
admin.site.register(Bookings, BookingsAdmin)
admin.site.register(Tournament, TournamentAdmin)
admin.site.register(TeamsGrup, TeamsGrupAdmin)
admin.site.register(TeamUs,TeamUsAdmin)
admin.site.register(TimeGraf,TimeGrafAdmin)








