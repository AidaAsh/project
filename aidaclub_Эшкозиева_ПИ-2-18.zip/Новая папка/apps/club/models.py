from django.db import models
from phonenumber_field.modelfields import PhoneNumberField
from django.contrib.auth.models import User
from django.contrib import admin

POSITION_CHOICES = [
    ('Пользователь', 'Пользователь'),
    ('Администратор', 'Администратор'),
    ('Менеджер', 'Менеджер'),
    ('Ученик', 'Ученик'),
    ('Тренер', 'Тренер'),
]
STATUS_CHOICES = [
    ('Ожидание', 'Ожидание'),
    ('Актив', 'Актив'),
    ('Отказ', 'Отказ')
]
STATUS_CHOICES1 = [
    ('Неактивен', 'Неактивен'),
    ('Активен', 'Активен'),
]
time_slots = (
    ('13:00 - 14:00', '13:00 - 14:00'),
    ('14:00 - 15:00', '14:00 - 15:00'),
    ('15:00 - 16:00', '15:00 - 16:00'),
    ('16:00 - 17:00', '16:00 - 17:00'),
    ('17:00 - 18:00', '17:00 - 18:00'),
    ('18:00 - 19:00', '18:00 - 19:00'),
    ('19:00 - 20:00', '19:00 - 20:00'),
    ('20:00 - 21:00', '20:00 - 21:00'),
    ('21:00 - 22:00', '21:00 - 22:00'),
    ('22:00 - 23:00', '22:00 - 23:00'),
    ('23:00 - 24:00', '23:00 - 24:00'),
)
time_slots1 = (
    ('13:00', '13:00 '),
    ('14:00', '14:00 '),
    ('15:00', '15:00 '),
    ('16:00', '16:00 '),
    ('17:00', '17:00 '),
    ('18:00', '18:00 '),
    ('19:00', '19:00 '),
    ('20:00', '20:00 '),
    ('21:00', '21:00 '),
    ('22:00', '22:00 '),
    ('23:00', '23:00 '),
)
time_slots2 = (

    ('14:00', '14:00 '),
    ('15:00', '15:00 '),
    ('16:00', '16:00 '),
    ('17:00', '17:00 '),
    ('18:00', '18:00 '),
    ('19:00', '19:00 '),
    ('20:00', '20:00 '),
    ('21:00', '21:00 '),
    ('22:00', '22:00 '),
    ('23:00', '23:00 '),
    ('24:00', '24:00 '),
)
time_slots3 = (
    ('08:00', '08:00 '),
    ('09:00', '09:00 '),
    ('10:00', '10:00 '),
    ('11:00', '11:00 '),
    ('12:00', '12:00 '),
)
time_slots4 = (
    ('09:00', '09:00 '),
    ('10:00', '10:00 '),
    ('11:00', '11:00 '),
    ('12:00', '12:00 '),
    ('13:00', '13:00 '),
)
WEEK_CHOICES = [
    ('Понедельник', 'Понедельник'),
    ('Вторник', 'Вторник'),
    ('Среда', 'Среда'),
    ('Четверг', 'Четверг'),
    ('Пятница', 'Пятница'),
    ('Суббота', 'Суббота'),
    ('Воскресенье', 'Воскресенье'),
]

class UserClub(models.Model):
    """
    Модель Администратор которая подтягивает данные из внешней API
    """
    OTHER = "OTHER"

    GENDER = (
        ("M", 'мужчина'),
        ("F", 'женщина'),
        (OTHER, "другое")
    )

    MARRIED = 'Married'
    SINGLE = 'Single'
    WIDOWED = 'Widowed'
    DIVORCED = 'Divorced'

    MARITAL_STATUS = (
        (SINGLE, "не замужем / не женат"),
        (MARRIED, "замужем / женат"),
        (DIVORCED, "разведен / разведена"),
        (WIDOWED, "вдовец / вдова")
    )
    user = models.OneToOneField(User, on_delete=models.CASCADE,blank=True,null=True)

    first_name = models.CharField(max_length=255, verbose_name="Имя")
    surname = models.CharField(max_length=255, verbose_name="Фамилия")
    last_name = models.CharField(max_length=255, verbose_name="Отчество")
    number_phone = PhoneNumberField(region="KG")
    email = models.EmailField()
    data_of_birth = models.DateField()
    nationality = models.CharField(max_length=255, verbose_name="Национальность")
    gender = models.CharField(choices=GENDER, default="M", max_length=8, verbose_name="Пол")
    imeag = models.ImageField("Фотография", upload_to='', blank=True, null=True)
    citizenship = models.CharField( verbose_name="Гражданство",max_length=255, null=True)
    marital_status = models.CharField(choices=MARITAL_STATUS, default=SINGLE,
                                      max_length=8, verbose_name="Семейный статус", blank=True)

    create_date = models.DateField(auto_now_add=True)
    
    @property
    def full_name(self):
        
        return self.surname + " " + self.first_name + " " + self.last_name

    @property
    def full_name(self):
        return self.surname + " " + self.first_name + " " + self.last_name
    
    def __str__(self):
        return self.full_name

    class Meta:
        verbose_name = "Пользователи"
        verbose_name_plural = "Пользователи"


class PositionClub(models.Model):
    userclub = models.ForeignKey(UserClub, on_delete=models.CASCADE, related_name="managerclub")
    position = models.CharField(max_length=255, verbose_name="Позиция" , choices=POSITION_CHOICES)

    def make_trainer(modeladmin, request, queryset):
        queryset.update(status='Тренер')

    def __str__(self):
        return self.userclub.full_name

    class Meta:
        verbose_name = "Позиция"
        verbose_name_plural = "Позиция"


class Bookings(models.Model):
    userclub = models.ForeignKey(UserClub, on_delete=models.CASCADE, related_name="bookings")
    date_of_booking = models.DateField(verbose_name="Дата брони")
    date_of_today = models.DateField(verbose_name="Забронированная брони", blank=True, null=True)
    timestart = models.CharField(max_length=255, verbose_name="Время начала", choices=time_slots1)
    timeend = models.CharField(max_length=255, verbose_name="Время окончания", choices=time_slots2)
    email = models.CharField(max_length=255, verbose_name="Номер", blank=True, null=True)
    status =models.CharField(max_length=255, verbose_name="Статус", blank=True, null=True, choices=STATUS_CHOICES)

    def __str__(self):
        return self.userclub.full_name
    class Meta:
        verbose_name = "Брони поля"
        verbose_name_plural = "Брони поля"


class TeamLessons(models.Model):
    team = models.CharField(max_length=255, verbose_name="Команда")
    #traner =models.ForeignKey(UserClub, on_delete=models.CASCADE, related_name="teamslessons",blank=True)
    first_name = models.CharField(max_length=255, verbose_name="Имя")
    surname = models.CharField(max_length=255, verbose_name="Фамилия")
    number_phone = models.CharField(max_length=255, verbose_name="Номер телефона")
    email = models.CharField(max_length=255, verbose_name="Почта")
    data_of_birth = models.DateField(verbose_name="Дата рождения")
    gender = models.CharField(max_length=255, verbose_name="Пол")

    def __str__(self):
        return self.team

    class Meta:
        verbose_name = "Регистрация участника"
        verbose_name_plural = "Регистрация участника"


class Tournament(models.Model):
    team_one = models.CharField(max_length=255, verbose_name="Команда 1")
    team_two = models.CharField(max_length=255, verbose_name="Команда 2")
    date_of_booking = models.DateField(verbose_name="Дата брони")
    date_of_today = models.DateField(verbose_name="Забронированная брони", blank=True, null=True)
    timestart = models.CharField(max_length=255, verbose_name="Время начала", choices=time_slots1)
    timeend = models.CharField(max_length=255, verbose_name="Время окончания", choices=time_slots2)

    def __str__(self):
        return self.team_one + " x " + self.team_two

    class Meta:
        verbose_name = "Турниры"
        verbose_name_plural = "Турниры"

class Tourney(models.Model):
    tourney = models.CharField(max_length=255, verbose_name="Турнир")
    dateoft = models.DateField(verbose_name="Дата турнира", blank=True, null=True)
    date_of_booking = models.DateField(verbose_name="Дата брони")
    date_of_today = models.DateField(verbose_name="Забронированная брони", blank=True, null=True)
    timestart = models.CharField(max_length=255, verbose_name="Время начала")
    timeend = models.CharField(max_length=255, verbose_name="Время окончания")


class TeamsGrup(models.Model):
    group = models.CharField(max_length=255, verbose_name="Наименование группы")
    #traner =models.ForeignKey(UserClub, on_delete=models.CASCADE, related_name="teamsgrup",blank=True)
    first_name = models.CharField(max_length=255, verbose_name="Имя")
    surname = models.CharField(max_length=255, verbose_name="Фамилия")
    last_name = models.CharField(max_length=255, verbose_name="Отчество")
    number_phone = models.CharField(max_length=255, verbose_name="Номер телефона")
    email = models.CharField(max_length=255, verbose_name="Почта")
    data_of_birth = models.DateField(verbose_name="Дата рождения", blank=True, null=True)
    gender = models.CharField(max_length=255, verbose_name="Пол")
    #is_tourney = models.BooleanField(verbose_name="Участвует в турнире")

    def __str__(self):
        return self.group+ " --- тренер " + self.surname
    class Meta:
        verbose_name = "Группы"
        verbose_name_plural = "Группы"


class TeamUs(models.Model):
    groups = models.ForeignKey(TeamsGrup, on_delete=models.CASCADE, related_name="teamus")
    first_name = models.CharField(max_length=255, verbose_name="Имя")
    surname = models.CharField(max_length=255, verbose_name="Фамилия",)
    last_name = models.CharField(max_length=255, verbose_name="Отчество", blank=True, null=True)
    number_phone = models.CharField(max_length=255, verbose_name="Номер телефона", blank=True, null=True)
    email = models.CharField(max_length=255, verbose_name="Почта", blank=True, null=True)
    data_of_birth = models.DateField(verbose_name="Дата рождения", blank=True, null=True)
    gender = models.CharField(max_length=255, verbose_name="Пол", blank=True, null=True)

    def __str__(self):
        return self.groups.group + " --- " + self.first_name
    class Meta:
        verbose_name = "Команда"
        verbose_name_plural = "Команда"


class TimeGraf(models.Model):
    teamlessons= models.ForeignKey(TeamsGrup, on_delete=models.CASCADE, related_name="timegraf",verbose_name="Группы")
    time =models.CharField(max_length=255,verbose_name="Время начала", blank=True, null=True, choices=time_slots3 )
    timeend =models.CharField(max_length=255,verbose_name="Время окончания", blank=True, null=True,choices= time_slots4)
    weeks = models.CharField(max_length=255,verbose_name="День недели",default='Понедельник', null=True, choices=WEEK_CHOICES)

    def __str__(self):
        return self.teamlessons.group + '  ---  ' + self.weeks+'  ---  ' + self.time

    class Meta:
        verbose_name = "Расписание на неделю"
        verbose_name_plural = "Расписание на неделю"