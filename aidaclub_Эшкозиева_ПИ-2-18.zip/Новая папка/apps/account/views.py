
from django.shortcuts import redirect, render
from django.http import HttpRequest, HttpResponse
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.models import User, Group
from apps.club.models import *
from .forms import *


from random import randint

"""
Проверка на группу
"""


"""
create function for login
"""
def user_login(request):
    error=''

    
    if request.method == "POST":


                log=request.POST.get('login')
                passw=request.POST.get('password')
                user = authenticate(username=log, password=passw)
                testing=''


                print("Чек")
                if user is not None:
                    if user.is_active:
                            print("Чек")

                            login(request, user)
                            return redirect('accountuser', id=user.id)

                    else:
                        error='Неправильный логин или пароль'
                        return render(request,'auth.html', {'error':error})
                else:
                    error='Неправильный логин или пароль'
                    return render(request,'auth.html', {'error':error})

        



    else:
                    error=''
                    return render(request,'auth.html', {'error':error})
            
    return render(request, 'auth.html')
                

    

    
def accoutscheck(request, id):
                    user = User.objects.get(id=id)
                    return redirect('accountuser', id=user.id)





def errors(request):
    return render(request, "errors.html")

def user_logout(request: HttpRequest):
    logout(request)
    return redirect('home')

def Register(request):
    if request.method == "GET":
        form = UploadFileForm(request.POST, request.FILES)
        return render(request, "registration.html", {"form":form})
    if request.method == "POST":
            #form = UploadFileForm(request.POST, request.FILES)
            queryfirstname = request.POST.get('first_name')
            querysurname = request.POST.get('surname')
            querylastname = request.POST.get('last_name')
            querydataofbirth = request.POST.get('data_of_birth')
            querynumber_phone = request.POST.get('number_phone')
            querygender = request.POST.get('gender')
            #files = request.FILES['file']
            queryemail = request.POST.get('email')

            UserClub.objects.create(first_name=queryfirstname, surname=querysurname, last_name=querylastname,
                                   data_of_birth=querydataofbirth, number_phone=querynumber_phone,
                                   gender=querygender,
                                  email=queryemail)

            obj = UserClub.objects.latest('id')

            positions = "Пользователь"
            PositionClub.objects.create(userclub=obj,position=positions)
            passwords = request.POST.get('pass')
            User.objects.create_user(username=queryemail,
                                    email=queryemail,
                                   password=passwords)

            user = authenticate(username=queryemail, password=passwords)
            login(request, user)
            return redirect('accountuser', id=user.id)




    return render(request, "registration.html")






