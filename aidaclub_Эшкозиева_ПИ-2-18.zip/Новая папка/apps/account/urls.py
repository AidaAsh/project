from django.urls import path
from . import views
from .views import *

urlpatterns = [
    path("login/", views.user_login, name="login"),
    path("logout/", views.user_logout, name="logout"),
    path("checklog/",views.user_login, name="checklog"),
    
    path('errors/', views.errors, name='errors'),
    path('accountlc/<int:id>', views.accoutscheck, name='accountlc'),
    path("registers/", views.Register, name="registers"),

    
   
]