import smtplib
from email.mime.text import MIMEText
"""
Отправка сообщения на почту
"""
def send_email(message):

    sender = "kstusgpkg@gmail.com"
    password = "Lee4436s"

    server = smtplib.SMTP("smtp.gmail.com", 587)
    server.starttls()

    try:
        server.login(sender, password)
        msg=MIMEText(message)
        server.sendmail(sender, sender, msg.as_string())
        #server.sendmail(sender, sender, f"Subject: Код для входа в SGP-KSTU!\n{message}" )

        return "Сообщение отрпавлено на почту"
    except Exception as _ex:
        return f"{_ex}\nНеправильный логин или пароль"

def main():
    
    message = input("Ваше сообщение:")
    print(send_email(message=message))
    
if __name__ == "__main__":
    main()

