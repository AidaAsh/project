const booking = document.querySelector('.user-action__button:first-child');
const bookingButtons = document.querySelector('.user-actions__buttons');
const userButtons = document.querySelectorAll('.user-action.user .user-action__button');
const userActionButtons = document.querySelector('.user-actions__buttons.user')
const backButtons = document.querySelector('.user-action__button.back')
const actions = document.querySelector('.user-action.user')

booking.addEventListener('click', () => {
    booking.classList.add('deactived');
    bookingButtons.classList.add('active');
})

const position = document.querySelector('.position');
const userAction = document.querySelectorAll(".user-action");
// const drop_department = document.querySelector(".drop_department");
// const li_department = document.querySelector(".li_department");


document.addEventListener('DOMContentLoaded', () => {
    
    userAction.forEach(item => {
        item.style.display = 'none';

    });

    userAction.forEach((item, index) => {

        const num2 = userAction[index];
        
        if (position.textContent == num2.dataset.positionState) {
            item.style.display = 'block';
        }
    });
})
actions.addEventListener('click', (e) => {
    if(e.target.classList.contains('selected')) {
        
            userButtons.forEach(item => {
                
                item.style.display = 'none';
            })
           
            userActionButtons.classList.add('active');
            const childrends = userActionButtons.children
            for(let i = 0; i < childrends.length; i++) {
                childrends.item(i).style.display = 'block';
                
            }
            userActionButtons.style.display = 'block'
    }
})
// userButtons.forEach(item => {
//     if(item.classList.contains('selected')) {
//         item.addEventListener('click', () => {
//             userButtons.forEach(item => {
//                 item.style.display = 'none';
//             })
           
//             userActionButtons.classList.add('active');
//             const childrends = userActionButtons.children
//             for(let i = 0; i < childrends.length; i++) {
//                 childrends.item(i).style.display = 'block';
                
//             }
//         })
//     }
// })

backButtons.addEventListener('click', () => {
    userButtons.forEach(item => {
        item.style.display = 'block';
    })
    userActionButtons.style.display = 'none';
})