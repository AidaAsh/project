const dateInput = document.querySelector('.booking-date');
const today = new Date()
console.log(today.getDate())
console.log(today.getMonth())
let month
let day
if(today.getMonth() > 11) {
    month = `01`
}
else if(today.getMonth() < 10){
    month = `0${today.getMonth() + 1}`
}else {
    month = `${today.getMonth() + 1}`
}
if(today.getDate() < 10) {
    day = `0${today.getDate()}`
}else {
    day = `${today.getDate()}`
}

let minDate = `${today.getFullYear()}-${month}-${day}`


dateInput.min = minDate

