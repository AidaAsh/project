window.addEventListener('DOMContentLoaded', () => {
    const inputs = document.querySelectorAll(".input");
    const agreement = document.querySelector(".form-card-grid__agreement");
    const input = agreement.querySelectorAll(".input");


    input.forEach(elem => {
        if (elem.placeholder == 'Согласован') {
            elem.classList.add('input__green');
        } else if (elem.placeholder == 'В приказ') {
            elem.classList.add('input__blue');
        } else if (elem.placeholder == 'Подписан') {
            elem.classList.add('input__blue');
        } else if (elem.placeholder == 'Отказ') {
            elem.classList.add('input__red');
        }
    });

    inputs.forEach(elem => {
        if (elem.placeholder == 'None') {
            elem.placeholder = '----';
        } else if (elem.placeholder == 'none') {
            elem.placeholder = '----';
        }
    });

    input.forEach(elem => {
        if (elem.value == 'Согласован') {
            elem.classList.add('input__green');
        } else if (elem.value == 'В приказ') {
            elem.classList.add('input__blue');
        } else if (elem.value == 'Подписан') {
            elem.classList.add('input__blue');
        } else if (elem.value == 'Отказ') {
            elem.classList.add('input__red');
        }
    });

    inputs.forEach(elem => {
        if (elem.value == 'None') {
            elem.value = '----';
        } else if (elem.value == 'none') {
            elem.value = '----';
        }
    });

    const inputs1 = document.querySelectorAll(".input");
    const agreement1 = document.querySelector(".formsss");
    const input1 = agreement1.querySelectorAll(".input");


    input1.forEach(elem => {
        if (elem.placeholder == 'Согласован') {
            elem.classList.add('input__green');
        } else if (elem.placeholder == 'В приказ') {
            elem.classList.add('input__blue');
        } else if (elem.placeholder == 'Подписан') {
            elem.classList.add('input__blue');
        } else if (elem.placeholder == 'Отказ') {
            elem.classList.add('input__red');
        }
    });

    inputs1.forEach(elem => {
        if (elem.placeholder == 'None') {
            elem.placeholder = '----';
        } else if (elem.placeholder == 'none') {
            elem.placeholder = '----';
        }
    });

    input1.forEach(elem => {
        if (elem.value == 'Согласован') {
            elem.classList.add('input__green');
        } else if (elem.value == 'В приказ') {
            elem.classList.add('input__blue');
        } else if (elem.value == 'Подписан') {
            elem.classList.add('input__blue');
        } else if (elem.value == 'Отказ') {
            elem.classList.add('input__red');
        }
    });

    inputs1.forEach(elem => {
        if (elem.value == 'None') {
            elem.value = '----';
        } else if (elem.value == 'none') {
            elem.value = '----';
        }
    });

});


    

