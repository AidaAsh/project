document.addEventListener('DOMContentLoaded', () => {
    const agreement = document.querySelector('.agreement');
    const agreement_refusal = agreement.querySelector('.agreement-refusal');
    const agreement_accept = agreement.querySelector('.agreement-accept');
    const button_ref = document.querySelector('.button-ref');
    const button_acc = document.querySelector('.button-acc');
    const button_clsref = document.querySelector('.button-clsref');
    const button_clsacc = document.querySelector('.button-clsacc');

    button_ref.addEventListener('click', () => {
        agreement_accept.classList.remove('agreement-accept__active');
        agreement_refusal.classList.add('agreement-refusal__active');
    });

    button_acc.addEventListener('click', () => {
        agreement_refusal.classList.remove('agreement-refusal__active');
        agreement_accept.classList.add('agreement-accept__active');
    });

    button_clsref.addEventListener('click', () => {
        agreement_refusal.classList.remove('agreement-refusal__active');
    });
    button_clsacc.addEventListener('click', () => {
        agreement_accept.classList.remove('agreement-accept__active');
    });
});