const formTabs = document.querySelectorAll(".form__tab");
const tabsItem = document.querySelectorAll(".tab_item");
const nextBtn = document.querySelectorAll(".next-btn");
const prevBtn = document.querySelectorAll(".prev-btn");

formTabs.forEach(function (item) {
    item.addEventListener("click", function () {
        let currentTabBtn = item;
        let formTabId = currentTabBtn.getAttribute("data-tab");
        let currentTab = document.querySelector(formTabId);

        formTabs.forEach(function (item) {
            item.classList.remove("form__tab_active");
        });

        tabsItem.forEach(function (item) {
            item.classList.add("form-not-active");
        });

        currentTabBtn.classList.add("form__tab_active");
        currentTab.classList.remove("form-not-active");
    });
});

nextBtn.forEach(function (item) {
    item.addEventListener("click", function () {
        let currentTabBtn = item.getAttribute("data-tab");
        formTabs.forEach(function (item) {
            if (currentTabBtn == item.getAttribute("data-tab")) {
                item.classList.add("form__tab_active");
            }
        });
    })
});

prevBtn.forEach(function (item) {
    item.addEventListener("click", function () {
        let currentTabBtn = item.getAttribute("data-tab");
        formTabs.forEach(function (item) {
            if (currentTabBtn == item.getAttribute("data-tab")) {
                item.classList.add("form__tab_active");
            }
        });
    })
});