                const input_country = document.querySelector(".input_country");
const input_region = document.querySelector(".input_region");
const input_city = document.querySelector(".input_city");
const input_district = document.querySelector(".input_district");
const country_check = document.querySelectorAll(".country_check");
const region_check = document.querySelectorAll(".region_check");
const city_check = document.querySelectorAll(".city_check");
const village_check = document.querySelectorAll(".village_check");
const drop = document.querySelector(".drop");
const drop_city = document.querySelector(".drop_city");
const drop_district = document.querySelector(".drop_district");
const drop_district_of_city = document.querySelector(".drop_district_of_city");
const drop_village = document.querySelector(".drop_village");

const country_check2 = document.querySelectorAll(".country_check2");
const country_check3 = document.querySelectorAll(".country_check3");
const country_check4 = document.querySelectorAll(".country_check4");
const country_check5 = document.querySelectorAll(".country_check5");
const country_check6 = document.querySelectorAll(".country_check");

drop.addEventListener('click', () => {

  country_check2.forEach(item => {
          item.style.display = 'none';

      });

      country_check2.forEach((item, index) => {
        const num2 = country_check[index];
        if (input_country.value == num2.value) {
                     item.style.display = 'block';
              }
      });
})

drop_city.addEventListener('click', () => {

  country_check3.forEach(item => {
       item.style.display = 'none';

   });

   country_check3.forEach((item, index) => {
     const num2 = region_check[index];
   
     if (input_region.value == num2.value) {
                  item.style.display = 'block';
           }
   });
})

drop_district.addEventListener('click', () => {

country_check4.forEach(item => {
     item.style.display = 'none';

 });

 country_check4.forEach((item, index) => {
   const num2 = region_check[index];
   
   if (input_region.value == num2.value) {
                item.style.display = 'block';
         }
 });
})

drop_village.addEventListener('click', () => {

country_check5.forEach(item => {
     item.style.display = 'none';

 });

 country_check5.forEach((item, index) => {
   const num2 = village_check[index];
   
   if (input_district.value == num2.value) {
                item.style.display = 'block';
         }
 });
})

drop_district_of_city.addEventListener('click', () => {

country_check6.forEach(item => {
     item.style.display = 'none';

 });

 country_check6.forEach((item, index) => {
   const num2 = city_check[index];
  
   if (input_city.value == num2.value) {
                item.style.display = 'block';
         }
 });
})


const dropInput = document.querySelector('input.drop');
  const dropList = document.querySelector('ul.drop');
  dropInput.addEventListener('focus', show, false);
  dropInput.addEventListener('blur', hide, false);
  dropList.addEventListener('click', dropSelect, false);

  function hide(){
    setTimeout(() =>
      dropList.classList.remove('visible'),
    300);
  }
  function show(){
    setTimeout(() =>
      dropList.classList.add('visible'),
    300);
  }

  function dropSelect(e) {
    dropInput.value = e.target.textContent
    hide();
  }

  const dropInput_city = document.querySelector('input.drop_city');
  const dropList_city = document.querySelector('ul.drop_city');
  dropInput_city.addEventListener('focus', show_city, false);
  dropInput_city.addEventListener('blur', hide_city, false);
  dropList_city.addEventListener('click', dropSelect_city, false);

  function hide_city(){
    setTimeout(() =>
      dropList_city.classList.remove('visible'),
    300);
  }
  function show_city(){
    setTimeout(() =>
      dropList_city.classList.add('visible'),
    300);
  }

  function dropSelect_city(e) {
    dropInput_city.value = e.target.textContent
    hide();
  }

  const dropInput_district = document.querySelector('input.drop_district');
  const dropList_district = document.querySelector('ul.drop_district');
  dropInput_district.addEventListener('focus', show_district, false);
  dropInput_district.addEventListener('blur', hide_district, false);
  dropList_district.addEventListener('click', dropSelect_district, false);

  function hide_district(){
    setTimeout(() =>
      dropList_district.classList.remove('visible'),
    300);
  }
  function show_district(){
    setTimeout(() =>
      dropList_district.classList.add('visible'),
    300);
  }

  function dropSelect_district(e) {
    dropInput_district.value = e.target.textContent
    hide();
  }


  const dropInput_district_of_city = document.querySelector('input.drop_district_of_city');
  const dropList_district_of_city = document.querySelector('ul.drop_district_of_city');
  dropInput_district_of_city.addEventListener('focus', show_district_of_city, false);
  dropInput_district_of_city.addEventListener('blur', hide_district_of_city, false);
  dropList_district_of_city.addEventListener('click', dropSelect_district_of_city, false);

  function hide_district_of_city(){
    setTimeout(() =>
      dropList_district_of_city.classList.remove('visible'),
    300);
  }
  function show_district_of_city(){
    setTimeout(() =>
      dropList_district_of_city.classList.add('visible'),
    300);
  }

  function dropSelect_district_of_city(e) {
    dropInput_district_of_city.value = e.target.textContent
    hide();
  }


  const dropInput_village = document.querySelector('input.drop_village');
  const dropList_village = document.querySelector('ul.drop_village');
  dropInput_village.addEventListener('focus', show_village, false);
  dropInput_village.addEventListener('blur', hide_village, false);
  dropList_village.addEventListener('click', dropSelect_village, false);

  function hide_village(){
    setTimeout(() =>
      dropList_village.classList.remove('visible'),
    300);
  }
  function show_village(){
    setTimeout(() =>
      dropList_village.classList.add('visible'),
    300);
  }

  function dropSelect_village(e) {
    dropInput_village.value = e.target.textContent
    hide();
  }