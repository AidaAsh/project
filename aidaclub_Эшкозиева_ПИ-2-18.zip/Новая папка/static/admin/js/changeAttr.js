document.addEventListener('DOMContentLoaded', () => {
    const division = document.querySelectorAll('.division'),
    department = document.querySelectorAll('.department'),
    category = document.querySelectorAll('.category'),
    position = document.querySelectorAll('.position'),
    stavka = document.querySelectorAll('.stavka'),
    state = document.querySelectorAll('.state'),
    idempl = document.querySelectorAll('.idempl'),
    order_them = document.querySelectorAll('.order_them');

   
    let i = 0;
    idempl.forEach(item => {
        item.setAttribute('name', 'idempl' + i);
        i++;
    });

    i = 0;
    division.forEach(item => {
        item.setAttribute('name', 'division' + i);
        i++;
    });

    i = 0;
    department.forEach(item => {
        item.setAttribute('name', 'department' + i);
        i++;
    });

    i = 0;
    category.forEach(item => {
        item.setAttribute('name', 'category' + i);
        i++;
    });

    i = 0;
    position.forEach(item => {
        item.setAttribute('name', 'position' + i);
        i++;
    });

    i = 0;
    stavka.forEach(item => {
        item.setAttribute('name', 'stavka' + i);
        i++;
    });

    i = 0;
    state.forEach(item => {
        item.setAttribute('name', 'state' + i);
        i++;
    });

    i = 0;
    order_them.forEach(item => {
        item.setAttribute('name', 'order_them' + i);
        i++;
    });
})