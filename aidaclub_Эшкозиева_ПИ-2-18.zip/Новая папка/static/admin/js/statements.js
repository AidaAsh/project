//Для Кафедр
const input_divisions = document.querySelector('.input_divisions');
const check_divisions = document.querySelectorAll(".check_divisions");
const drop_department = document.querySelector(".drop_department");
const li_department = document.querySelector(".li_department");


drop_department.addEventListener('click', () => {
    
    li_department.forEach(item => {
        item.style.display = 'none';

    });

    li_department.forEach((item, index) => {
        const num2 = check_divisions[index];
        console.log(num2);
        if (input_divisions.value == num2.value) {
            item.style.display = 'block';
        }
    });
})


const dropInput_department = document.querySelector('input.drop_department');
const dropList_department = document.querySelector('ul.drop_department');
dropInput_department.addEventListener('focus', show_department, false);
dropInput_department.addEventListener('blur', hide_department, false);
dropList_department.addEventListener('click', dropSelect_department, false);

function hide_department() {
    setTimeout(() =>
        dropList_department.classList.remove('visible'),
        300);
}

function show_department() {
    setTimeout(() =>
        dropList_department.classList.add('visible'),
        300);
}

function dropSelect_department(e) {
    dropInput_department.value = e.target.textContent
    hide();
}

//Для Должностей
const drop_position = document.querySelector(".drop_position");
const li_position = document.querySelector(".li_position");

drop_position.addEventListener('click', () => {

    li_position.forEach(item => {
        item.style.display = 'none';

    });

    li_position.forEach((item, index) => {
        const num2 = check_divisions[index];
        if (input_divisions.value == num2.value) {
            item.style.display = 'block';
        }
    });
})


const dropInput_position = document.querySelector('input.drop_position');
const dropList_position = document.querySelector('ul.drop_position');
dropInput_position.addEventListener('focus', show_position, false);
dropInput_position.addEventListener('blur', hide_position, false);
dropList_position.addEventListener('click', dropSelect_position, false);

function hide_position() {
    setTimeout(() =>
        dropList_position.classList.remove('visible'),
        300);
}

function show_position() {
    setTimeout(() =>
        dropList_position.classList.add('visible'),
        300);
}

function dropSelect_position(e) {
    dropInput_position.value = e.target.textContent
    hide();
}